# GENESIS Portal – Phase 1 Commit

This commit contains:
- Full README
- Initial UI layout (React)
- Docs skeleton
- Field mapping templates
