# Field Mapping Template

| Dolibarr Field | GENESIS Field | Notes |
|---|---|---|
