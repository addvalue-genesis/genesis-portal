# ER Diagrams

Database entity–relationship diagrams for GENESIS and Dolibarr integration.
