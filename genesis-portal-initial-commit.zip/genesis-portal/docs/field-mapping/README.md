# Field Mapping

Dolibarr ERP → GENESIS field mapping specifications.
