import React from 'react';

export function App() {
  return (
    <div style={{ padding: '24px', fontFamily: 'sans-serif' }}>
      <h1>Addvalue GENESIS Portal</h1>
      <p>Initial frontend skeleton ready. This UI will be expanded step by step.</p>
    </div>
  );
}
