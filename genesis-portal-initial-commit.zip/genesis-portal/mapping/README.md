# Mapping Assets

Files that describe how Dolibarr tables/fields map into GENESIS tables.
